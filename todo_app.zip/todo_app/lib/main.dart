import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:todo_app/ui/Home.dart';

FirebaseUser _currentUser;
void main() async {
  _currentUser = await FirebaseAuth.instance.signInAnonymously();
  runApp(App());
}

class App extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: HomePage(),
      title: "Lista de Tarefas",
      theme: ThemeData(
          primaryColor: Colors.blueAccent,
          backgroundColor: Colors.blueAccent,
          bottomAppBarColor: Colors.blueAccent,
          textTheme:
              TextTheme(title: TextStyle(color: Colors.black45, fontSize: 15)),
          secondaryHeaderColor: Colors.yellowAccent),
    );
  }
}
