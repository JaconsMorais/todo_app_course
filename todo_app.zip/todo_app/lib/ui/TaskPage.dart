import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class TaskPage extends StatefulWidget {
  FirebaseUser user;
  @override
  _TaskPageState createState() => _TaskPageState();
}

class _TaskPageState extends State<TaskPage> {
  @override
  Widget build(BuildContext context) {
    return ListView(
      children: <Widget>[
        new Column(
          children: <Widget>[
            Padding(
              padding: EdgeInsets.only(top: 50),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  Expanded(
                    flex: 1,
                    child: Container(
                      color: Colors.grey,
                      height: 1.5,
                    ),
                  ),
                  Expanded(
                    flex: 2,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        Text(
                          'Minhas',
                          style: TextStyle(fontSize: 30, color: Colors.grey),
                        ),
                        Text(
                          'Tarefas',
                          style: TextStyle(
                              fontSize: 28,
                              color: Colors.blueAccent,
                              fontWeight: FontWeight.bold),
                        )
                      ],
                    ),
                  ),
                  Expanded(
                    flex: 1,
                    child: Container(
                      color: Colors.grey,
                      height: 1.5,
                    ),
                  )
                ],
              ),
            ),
            Padding(
              padding: EdgeInsets.only(top: 50),
              child: Column(
                children: <Widget>[
                  Container(
                    width: 50,
                    height: 50,
                    decoration: BoxDecoration(
                        border: Border.all(color: Colors.black38),
                        borderRadius: BorderRadius.all(Radius.circular(7))),
                    child: IconButton(
                      icon: Icon(Icons.add),
                      onPressed: null,
                      iconSize: 30,
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(top: 10),
                    child: Text(
                      'Adicionar Lista',
                      style: Theme.of(context).textTheme.title,
                    ),
                  )
                ],
              ),
            )
          ],
        ),
        Padding(
          padding: EdgeInsets.only(top: 50),
          child: Container(
            height: 360,
            padding: EdgeInsets.only(bottom: 25),
            child: NotificationListener<OverscrollIndicatorNotification>(
              onNotification: (overscroll) {
                overscroll.disallowGlow();
                return true;
              },
              child: StreamBuilder<QuerySnapshot>(
                stream: Firestore.instance
                    .collection(widget.user.uid)
                    .orderBy("date", descending: true)
                    .snapshots(),
                builder: (context, snapshot) {
                  return Container(
                    color: Colors.red,
                  );
                },
              ),
            ),
          ),
        )
      ],
    );
  }
}
